Configurations:

JBoss Portal specific configuration files
-----------------------------------------
jboss-app.xml
jboss-portlet.xml
jboss-web.xml
portlet-instances.xml
struts-example-object.xml
struts-example-pages.xml
